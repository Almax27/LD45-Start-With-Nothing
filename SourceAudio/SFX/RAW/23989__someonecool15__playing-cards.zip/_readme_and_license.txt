Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - SomeoneCool15 ( https://freesound.org/people/SomeoneCool15/ )

You can find this pack online at: https://freesound.org/people/SomeoneCool15/packs/23989/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 423769__someonecool13__playing-cards-being-delt.mp3
    * url: https://freesound.org/s/423769/
    * license: Creative Commons 0
  * 423768__someonecool13__playing-card-riffle.mp3
    * url: https://freesound.org/s/423768/
    * license: Creative Commons 0
  * 423767__someonecool13__card-shuffling.mp3
    * url: https://freesound.org/s/423767/
    * license: Creative Commons 0


